package application;
	
import java.io.FileInputStream;

import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;


public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			Pane root = new Pane();
			Scene scene = new Scene(root,800,950);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
			
			Book test = new Book(0,0);
			test.setSpeed(1);
			test.setDirection(1);
			Book test2 = new Book(0,200);
			Code test3 = new Code(0,300);
			Character test4 = new Character(0,400);
			test4.rotate(90);
			//TranslateTransition t = new TranslateTransition();
			//t.setNode(test.getImage());
			
		root.getChildren().addAll(test.getImage(), test2.getImage(),test3.getImage(),test4.getImage());

		    
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
