package application;

import javafx.event.ActionEvent;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Character 
{
	protected String fileName;
	protected double xvalue;
	protected double yvalue;
	protected int width;
	protected int height;
	protected double speed;
	protected int direction;
	protected Image image;
	protected ImageView view;
	
	
	public void setSpeed(int x)
	{
		speed = x;
	}
	public void setDirection(int x)
	{
		direction = x;
	}
	public ImageView getImage()
	{
		return view;
	}
	
	public Character(double x, double y)
	{
		fileName = "File:///" + System.getProperty("user.dir") + "/Character.png";
		width = 100; 
		height = 100;
		xvalue = x;
		yvalue = y;
		setupImage();
	}
	public void setupImage() //returns imageview to be added to scene
	{
		image = new Image(fileName);
		view = new ImageView(image);
		view.setX(xvalue); 
		view.setY(yvalue);
		view.setFitHeight(height); 
		view.setFitWidth(width); 
		view.setPreserveRatio(true); 
	}
	
	
	public void rotate(double x)
	{
	    view.setRotate(view.getRotate() + x); 
	}
}
