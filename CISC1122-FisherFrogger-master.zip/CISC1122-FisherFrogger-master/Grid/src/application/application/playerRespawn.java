package application;

import javafx.scene.control.Label;
import javafx.scene.shape.Circle;

public class playerRespawn
{

	void Respawn(Circle player, double x, double y)
	{
		player.setTranslateX(x);
		player.setTranslateY(y);
		
	}
	
	
}